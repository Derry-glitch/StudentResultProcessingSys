﻿string[] courseNames =
{
    "Programming with C#",
    "Database Systems",
    "Computer Networks",
    "Web Development",
    "Mathematics for Computing"
};

string[] studentNames = new string[3];
string[] studentIDs = new string[3];
string[] programmes = new string[3];
string[] levels = new string[3];

double[,] scores = new double[3, 5];
double[] totals = new double[3];
double[] averages = new double[3];
string[] grades = new string[3];
string[] statuses = new string[3];

bool resultsEntered = false;

while (true)
{
    Console.Clear();
    Console.WriteLine("===== STUDENT RESULTS PROCESSING SYSTEM =====");
    Console.WriteLine("1. Enter Student Results");
    Console.WriteLine("2. View Student Report");
    Console.WriteLine("3. Exit");
    Console.Write("Choose an option: ");

    string option = Console.ReadLine();

    if (option == "1")
    {
        Console.Clear();

        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine($"Enter details for Student {i + 1}");

            Console.Write("Enter full name: ");
            studentNames[i] = Console.ReadLine();

            Console.Write("Enter student ID: ");
            studentIDs[i] = Console.ReadLine();

            Console.Write("Enter programme: ");
            programmes[i] = Console.ReadLine();

            Console.Write("Enter level: ");
            levels[i] = Console.ReadLine();

            double total = 0;

            for (int j = 0; j < 5; j++)
            {
                double score;

                while (true)
                {
                    Console.Write($"Enter score for {courseNames[j]}: ");
                    string input = Console.ReadLine();

                    if (double.TryParse(input, out score) && score >= 0 && score <= 100)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid score. Score must be between 0 and 100.");
                    }
                }

                scores[i, j] = score;
                total += score;
            }

            totals[i] = total;
            averages[i] = total / 5;

            if (averages[i] >= 80)
            {
                grades[i] = "A";
            }
            else if (averages[i] >= 70)
            {
                grades[i] = "B";
            }
            else if (averages[i] >= 60)
            {
                grades[i] = "C";
            }
            else if (averages[i] >= 50)
            {
                grades[i] = "D";
            }
            else
            {
                grades[i] = "F";
            }

            if (averages[i] >= 50)
            {
                statuses[i] = "Passed";
            }
            else
            {
                statuses[i] = "Failed";
            }

            Console.WriteLine();
        }

        resultsEntered = true;

        Console.WriteLine("Student results entered successfully.");
        Console.WriteLine("Press any key to return to the menu...");
        Console.ReadKey();
    }
    else if (option == "2")
    {
        Console.Clear();

        if (resultsEntered == false)
        {
            Console.WriteLine("No student results have been entered yet.");
            Console.WriteLine("Please choose option 1 first.");
        }
        else
        {
            Console.WriteLine("===== STUDENT RESULTS REPORT =====");
            Console.WriteLine();

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"Student Name: {studentNames[i]}");
                Console.WriteLine($"Student ID: {studentIDs[i]}");
                Console.WriteLine($"Programme: {programmes[i]}");
                Console.WriteLine($"Level: {levels[i]}");

                for (int j = 0; j < 5; j++)
                {
                    Console.WriteLine($"{courseNames[j]}: {scores[i, j]}");
                }

                Console.WriteLine($"Total Score: {totals[i]}");
                Console.WriteLine($"Average Score: {averages[i]:F2}");
                Console.WriteLine($"Grade: {grades[i]}");
                Console.WriteLine($"Status: {statuses[i]}");

                Console.WriteLine("----------------------------------------");
            }
        }

        Console.WriteLine("Press any key to return to the menu...");
        Console.ReadKey();
    }
    else if (option == "3")
    {
        Console.WriteLine("Thank you for using the Student Results Processing System.");
        break;
    }
    else
    {
        Console.WriteLine("Invalid option. Please choose 1, 2, or 3.");
        Console.ReadKey();
    }
}